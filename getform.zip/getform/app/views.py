from django.shortcuts import render,HttpResponse


def first(request):
    # return HttpResponse("Hello World")
    return render(request,'app/index.html')

def second(request):
    fullname=request.GET['fullname']
    email=request.GET['email']
    password=request.GET['password']
    gender=request.GET['g']
    course=request.GET.getlist('c')
    city=request.GET['city']
    data={
        'fullname':fullname,
        'email':email,
        'password':password,
        'gender':gender,
        'course':course,
        'city':city,
    }
    return render(request,'app/index.html',data)

